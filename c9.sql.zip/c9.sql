-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-06-2015 a las 01:23:06
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `c9`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `academicas`
--

CREATE TABLE IF NOT EXISTS `academicas` (
`id` int(11) NOT NULL,
  `alumno_id` int(11) NOT NULL,
  `matricula` int(8) NOT NULL,
  `porcentaje` int(3) NOT NULL,
  `comentario` varchar(400) NOT NULL,
  `comentario2` varchar(100) NOT NULL,
  `comentario3` varchar(100) NOT NULL,
  `comentario4` varchar(100) NOT NULL,
  `comentario5` varchar(100) NOT NULL,
  `comentario6` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `academicas`
--

INSERT INTO `academicas` (`id`, `alumno_id`, `matricula`, `porcentaje`, `comentario`, `comentario2`, `comentario3`, `comentario4`, `comentario5`, `comentario6`, `created`, `modified`) VALUES
(4, 1, 11040039, 50, '1.- participo en todas las semanas academicas', '2.- participo en conferencia de sgvirtual', '', '', '', '', '2015-04-25 02:17:23', '2015-06-02 16:10:31');

--
-- Disparadores `academicas`
--
DELIMITER //
CREATE TRIGGER `bitacoras` AFTER INSERT ON `academicas`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'INSERTAR', NOW(), 'ACTIVIDADES ACADEMICAS')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `bitacoras_del` AFTER DELETE ON `academicas`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ELIMINAR', NOW(), 'ACTIVIDADES ACADEMICAS')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `bitacoras_upd` AFTER UPDATE ON `academicas`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ACTUALIZAR', NOW(), 'ACTIVIDADES ACADEMICAS')
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE IF NOT EXISTS `alumnos` (
`id` int(11) NOT NULL,
  `matricula` int(8) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidopaterno` varchar(30) NOT NULL,
  `apellidomaterno` varchar(30) NOT NULL,
  `semestre` int(2) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`id`, `matricula`, `nombre`, `apellidopaterno`, `apellidomaterno`, `semestre`, `created`, `modified`) VALUES
(1, 11040039, 'Aurelio', 'Hernandez', 'Briones', 8, '2015-03-12 04:18:19', '2015-04-25 00:43:51'),
(2, 11040045, 'Jose', 'Rosales', 'Acevedo', 8, '2015-03-12 05:05:09', '2015-03-12 05:05:09'),
(3, 11040041, 'Gumercindo', 'Lerma', 'Ortiz', 8, '2015-03-12 22:37:16', '2015-03-12 22:37:16'),
(4, 11040035, 'Cesar', 'Cisneros', 'Martinez', 8, '2015-03-12 22:49:18', '2015-03-12 22:50:59');

--
-- Disparadores `alumnos`
--
DELIMITER //
CREATE TRIGGER `bitacoras_al` AFTER INSERT ON `alumnos`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'INSERTAR', NOW(), 'ALUMNOS')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `del_bitacoras_al` AFTER DELETE ON `alumnos`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ELIMINAR', NOW(), 'ALUMNOS')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `upd_bitacoras_al` AFTER UPDATE ON `alumnos`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ACTUALIZAR', NOW(), 'ALUMNOS')
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bitacoras`
--

CREATE TABLE IF NOT EXISTS `bitacoras` (
`id` int(11) NOT NULL,
  `operacion` varchar(10) DEFAULT NULL,
  `usuario` varchar(40) DEFAULT NULL,
  `host` varchar(30) NOT NULL,
  `modificado` datetime DEFAULT NULL,
  `tabla` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `bitacoras`
--

INSERT INTO `bitacoras` (`id`, `operacion`, `usuario`, `host`, `modificado`, `tabla`) VALUES
(1, 'INSERTAR', 'yeyo1993', 'localhost', '2015-03-12 05:05:09', 'ALUMNOS'),
(2, 'ACTUALIZAR', 'root', 'localhost', '2015-03-12 15:36:10', 'ACTIVIDADES ACADEMICAS'),
(3, 'INSERTAR', 'root', 'localhost', '2015-03-12 15:37:16', 'ALUMNOS'),
(4, 'INSERTAR', 'root', 'localhost', '2015-03-12 15:38:05', 'ACTIVIDADES ACADEMICAS'),
(5, 'INSERTAR', 'root', 'localhost', '2015-03-12 15:49:18', 'ALUMNOS'),
(6, 'ACTUALIZAR', 'root', 'localhost', '2015-03-12 15:50:52', 'ALUMNOS'),
(7, 'ACTUALIZAR', 'root', 'localhost', '2015-03-12 15:50:59', 'ALUMNOS'),
(8, 'INSERTAR', 'root', 'localhost', '2015-03-12 15:51:19', 'ACTIVIDADES ACADEMICAS'),
(9, 'ACTUALIZAR', 'root', 'localhost', '2015-03-12 15:52:07', 'ACTIVIDADES ACADEMICAS'),
(10, 'INSERTAR', 'root', 'localhost', '2015-03-23 17:10:32', 'ALUMNOS'),
(11, 'INSERTAR', 'root', 'localhost', '2015-03-23 17:10:44', 'ALUMNOS'),
(12, 'ELIMINAR', 'root', 'localhost', '2015-03-23 17:11:27', 'ALUMNOS'),
(13, 'ELIMINAR', 'root', 'localhost', '2015-03-23 17:11:31', 'ALUMNOS'),
(14, 'ACTUALIZAR', 'root', 'localhost', '2015-03-23 17:11:40', 'ALUMNOS'),
(15, 'ACTUALIZAR', 'root', 'localhost', '2015-03-23 17:11:54', 'ALUMNOS'),
(16, 'ACTUALIZAR', 'root', 'localhost', '2015-03-23 17:12:00', 'ALUMNOS'),
(17, 'ACTUALIZAR', 'root', 'localhost', '2015-03-23 17:15:43', 'ACTIVIDADES EXTRAESCOLARES'),
(18, 'ACTUALIZAR', 'root', 'localhost', '2015-03-23 17:16:52', 'ACTIVIDADES ACADEMICAS'),
(19, 'ACTUALIZAR', 'root', 'localhost', '2015-03-23 17:17:02', 'ACTIVIDADES ACADEMICAS'),
(20, 'ACTUALIZAR', 'root', 'localhost', '2015-03-24 08:44:34', 'ALUMNOS'),
(21, 'ACTUALIZAR', 'root', 'localhost', '2015-03-24 08:44:47', 'ALUMNOS'),
(22, 'ACTUALIZAR', 'root', 'localhost', '2015-03-24 08:54:35', 'ALUMNOS'),
(23, 'ACTUALIZAR', 'root', 'localhost', '2015-03-24 08:55:06', 'ALUMNOS'),
(24, 'INSERTAR', 'root', 'localhost', '2015-03-24 09:40:08', 'ALUMNOS'),
(25, 'INSERTAR', 'root', 'localhost', '2015-03-24 09:40:39', 'ALUMNOS'),
(26, 'ELIMINAR', 'root', 'localhost', '2015-03-24 09:41:01', 'ALUMNOS'),
(27, 'ELIMINAR', 'root', 'localhost', '2015-03-24 09:42:09', 'ALUMNOS'),
(28, 'INSERTAR', 'root', 'localhost', '2015-03-24 09:42:59', 'ALUMNOS'),
(29, 'INSERTAR', 'root', 'localhost', '2015-03-24 10:14:41', 'ACTIVIDADES EXTRAESCOLARES'),
(30, 'INSERTAR', 'root', 'localhost', '2015-03-27 09:27:07', 'ALUMNOS'),
(31, 'ELIMINAR', 'root', 'localhost', '2015-03-27 09:29:21', 'ALUMNOS'),
(32, 'ELIMINAR', 'root', 'localhost', '2015-03-27 09:30:16', 'ALUMNOS'),
(33, 'INSERTAR', 'root', 'localhost', '2015-03-27 14:31:25', 'ACTIVIDADES ACADEMICAS'),
(34, 'ELIMINAR', 'root', 'localhost', '2015-03-27 14:35:13', 'ACTIVIDADES ACADEMICAS'),
(35, 'INSERTAR', 'root', 'localhost', '2015-04-21 15:03:10', 'ALUMNOS'),
(36, 'INSERTAR', 'root', 'localhost', '2015-04-21 22:12:27', 'ALUMNOS'),
(37, 'ACTUALIZAR', 'root', 'localhost', '2015-04-21 22:17:50', 'ALUMNOS'),
(38, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 17:43:51', 'ALUMNOS'),
(39, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:06:57', 'ACTIVIDADES ACADEMICAS'),
(40, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:07:03', 'ACTIVIDADES ACADEMICAS'),
(41, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:07:07', 'ACTIVIDADES ACADEMICAS'),
(42, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:18:45', 'ACTIVIDADES EXTRAESCOLARES'),
(43, 'ELIMINAR', 'root', 'localhost', '2015-04-24 18:26:37', 'ACTIVIDADES ACADEMICAS'),
(44, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:47:44', 'ACTIVIDADES ACADEMICAS'),
(45, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:47:54', 'ACTIVIDADES ACADEMICAS'),
(46, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:48:45', 'ACTIVIDADES ACADEMICAS'),
(47, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:52:05', 'ACTIVIDADES ACADEMICAS'),
(48, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 18:52:12', 'ACTIVIDADES ACADEMICAS'),
(49, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 19:00:35', 'ACTIVIDADES EXTRAESCOLARES'),
(50, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 19:16:08', 'ACTIVIDADES EXTRAESCOLARES'),
(51, 'INSERTAR', 'root', 'localhost', '2015-04-24 19:17:23', 'ACTIVIDADES ACADEMICAS'),
(52, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 19:18:13', 'FORMACION'),
(53, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 19:18:49', 'TUTORIAS'),
(54, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 19:19:32', 'INVESTIGACION'),
(55, 'ELIMINAR', 'root', 'localhost', '2015-04-24 19:44:43', 'ACTIVIDADES ACADEMICAS'),
(56, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 19:48:55', 'ACTIVIDADES ACADEMICAS'),
(57, 'ELIMINAR', 'root', 'localhost', '2015-04-24 19:49:00', 'ACTIVIDADES ACADEMICAS'),
(58, 'ACTUALIZAR', 'root', 'localhost', '2015-04-24 19:59:13', 'ACTIVIDADES ACADEMICAS'),
(59, 'ACTUALIZAR', 'root', 'localhost', '2015-06-02 09:07:32', 'ACTIVIDADES ACADEMICAS'),
(60, 'ACTUALIZAR', 'root', 'localhost', '2015-06-02 09:08:18', 'ACTIVIDADES ACADEMICAS'),
(61, 'ACTUALIZAR', 'root', 'localhost', '2015-06-02 09:10:31', 'ACTIVIDADES ACADEMICAS'),
(62, 'ACTUALIZAR', 'root', 'localhost', '2015-06-02 09:17:04', 'ACTIVIDADES EXTRAESCOLARES'),
(63, 'ACTUALIZAR', 'root', 'localhost', '2015-06-02 09:18:52', 'ACTIVIDADES EXTRAESCOLARES'),
(64, 'ELIMINAR', 'root', 'localhost', '2015-06-02 09:19:45', 'ACTIVIDADES EXTRAESCOLARES'),
(65, 'ACTUALIZAR', 'root', 'localhost', '2015-06-02 09:30:21', 'FORMACION'),
(66, 'ACTUALIZAR', 'root', 'localhost', '2015-06-09 17:00:58', 'ACTIVIDADES ACADEMICAS'),
(67, 'ACTUALIZAR', 'root', 'localhost', '2015-06-09 17:01:09', 'ACTIVIDADES EXTRAESCOLARES'),
(68, 'ACTUALIZAR', 'root', 'localhost', '2015-06-09 17:01:22', 'TUTORIAS'),
(69, 'ELIMINAR', 'root', 'localhost', '2015-06-09 18:20:52', 'ALUMNOS'),
(70, 'ELIMINAR', 'root', 'localhost', '2015-06-09 18:21:52', 'ALUMNOS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `extracurriculars`
--

CREATE TABLE IF NOT EXISTS `extracurriculars` (
`id` int(11) NOT NULL,
  `alumno_id` int(11) NOT NULL,
  `matricula` int(8) NOT NULL,
  `porcentaje` int(3) NOT NULL,
  `comentario` varchar(400) NOT NULL,
  `comentario2` varchar(100) NOT NULL,
  `comentario3` varchar(100) NOT NULL,
  `comentario4` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `extracurriculars`
--

INSERT INTO `extracurriculars` (`id`, `alumno_id`, `matricula`, `porcentaje`, `comentario`, `comentario2`, `comentario3`, `comentario4`, `created`, `modified`) VALUES
(1, 1, 11040039, 50, '1.- Tercer semestre en futbol', '2.- Cuarto semestre en futbol', '3.- Quinto semestre en futbol', '4.- Sexto semestre en futbol', '2015-03-12 04:36:41', '2015-06-02 16:18:52');

--
-- Disparadores `extracurriculars`
--
DELIMITER //
CREATE TRIGGER `bitacoras_extra` AFTER INSERT ON `extracurriculars`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'INSERTAR', NOW(), 'ACTIVIDADES EXTRAESCOLARES')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `del_bitacoras_extra` AFTER DELETE ON `extracurriculars`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ELIMINAR', NOW(), 'ACTIVIDADES EXTRAESCOLARES')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `upd_bitacoras_extra` AFTER UPDATE ON `extracurriculars`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ACTUALIZAR', NOW(), 'ACTIVIDADES EXTRAESCOLARES')
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `facademicas`
--
CREATE TABLE IF NOT EXISTS `facademicas` (
`id` int(11)
,`matricula` int(8)
,`nombre` varchar(20)
,`apellidopaterno` varchar(30)
,`apellidomaterno` varchar(30)
,`semestre` int(2)
,`created` datetime
,`modified` datetime
);
-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `fextracurriculars`
--
CREATE TABLE IF NOT EXISTS `fextracurriculars` (
`id` int(11)
,`matricula` int(8)
,`nombre` varchar(20)
,`apellidopaterno` varchar(30)
,`apellidomaterno` varchar(30)
,`semestre` int(2)
,`created` datetime
,`modified` datetime
);
-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `fformacions`
--
CREATE TABLE IF NOT EXISTS `fformacions` (
`id` int(11)
,`matricula` int(8)
,`nombre` varchar(20)
,`apellidopaterno` varchar(30)
,`apellidomaterno` varchar(30)
,`semestre` int(2)
,`created` datetime
,`modified` datetime
);
-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `finvestigacions`
--
CREATE TABLE IF NOT EXISTS `finvestigacions` (
`id` int(11)
,`matricula` int(8)
,`nombre` varchar(20)
,`apellidopaterno` varchar(30)
,`apellidomaterno` varchar(30)
,`semestre` int(2)
,`created` datetime
,`modified` datetime
);
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formacions`
--

CREATE TABLE IF NOT EXISTS `formacions` (
`id` int(11) NOT NULL,
  `alumno_id` int(11) NOT NULL,
  `matricula` int(8) NOT NULL,
  `porcentaje` int(3) NOT NULL,
  `comentario` varchar(400) NOT NULL,
  `comentario2` varchar(100) NOT NULL,
  `comentario3` varchar(100) NOT NULL,
  `comentario4` varchar(100) NOT NULL,
  `comentario5` varchar(100) NOT NULL,
  `comentario6` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `formacions`
--

INSERT INTO `formacions` (`id`, `alumno_id`, `matricula`, `porcentaje`, `comentario`, `comentario2`, `comentario3`, `comentario4`, `comentario5`, `comentario6`, `created`, `modified`) VALUES
(1, 1, 11040039, 75, 'no se que mas ', '', '', '', '', '', '2015-03-12 04:38:15', '2015-06-02 16:30:21');

--
-- Disparadores `formacions`
--
DELIMITER //
CREATE TRIGGER `bitacoras_form` AFTER INSERT ON `formacions`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'INSERTAR', NOW(), 'FORMACION')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `del_bitacoras_form` AFTER DELETE ON `formacions`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ELIMINAR', NOW(), 'FORMACION')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `upd_bitacoras_form` AFTER UPDATE ON `formacions`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ACTUALIZAR', NOW(), 'FORMACION')
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `ftutorias`
--
CREATE TABLE IF NOT EXISTS `ftutorias` (
`id` int(11)
,`matricula` int(8)
,`nombre` varchar(20)
,`apellidopaterno` varchar(30)
,`apellidomaterno` varchar(30)
,`semestre` int(2)
,`created` datetime
,`modified` datetime
);
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `investigacions`
--

CREATE TABLE IF NOT EXISTS `investigacions` (
`id` int(11) NOT NULL,
  `alumno_id` int(11) NOT NULL,
  `matricula` int(8) NOT NULL,
  `porcentaje` int(3) NOT NULL,
  `comentario` varchar(400) NOT NULL,
  `comentario2` varchar(100) NOT NULL,
  `comentario3` varchar(100) NOT NULL,
  `comentario4` varchar(100) NOT NULL,
  `comentario5` varchar(100) NOT NULL,
  `comentario6` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `investigacions`
--

INSERT INTO `investigacions` (`id`, `alumno_id`, `matricula`, `porcentaje`, `comentario`, `comentario2`, `comentario3`, `comentario4`, `comentario5`, `comentario6`, `created`, `modified`) VALUES
(1, 1, 11040039, 100, 'participo en el 1er encuentro de jovenes investigadores', '', '', '', '', '', '2015-03-12 04:38:43', '2015-04-25 02:19:32');

--
-- Disparadores `investigacions`
--
DELIMITER //
CREATE TRIGGER `bitacoras_inv` AFTER INSERT ON `investigacions`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'INSERTAR', NOW(), 'INVESTIGACION')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `del_bitacoras_inv` AFTER DELETE ON `investigacions`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ELIMINAR', NOW(), 'INVESTIGACION')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `upd_bitacoras_inv` AFTER UPDATE ON `investigacions`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ACTUALIZAR', NOW(), 'INVESTIGACION')
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tutorias`
--

CREATE TABLE IF NOT EXISTS `tutorias` (
`id` int(11) NOT NULL,
  `alumno_id` int(11) NOT NULL,
  `matricula` int(8) NOT NULL,
  `porcentaje` int(3) NOT NULL,
  `comentario` varchar(400) NOT NULL,
  `comentario2` varchar(100) NOT NULL,
  `comentario3` varchar(100) NOT NULL,
  `comentario4` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tutorias`
--

INSERT INTO `tutorias` (`id`, `alumno_id`, `matricula`, `porcentaje`, `comentario`, `comentario2`, `comentario3`, `comentario4`, `created`, `modified`) VALUES
(1, 1, 11040039, 50, 'asistio a todas las clases de tutoria', '', '', '', '2015-03-12 04:27:17', '2015-04-25 02:18:49');

--
-- Disparadores `tutorias`
--
DELIMITER //
CREATE TRIGGER `bitacoras_tut` AFTER INSERT ON `tutorias`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'INSERTAR', NOW(), 'TUTORIAS')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `del_bitacoras_tut` AFTER DELETE ON `tutorias`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ELIMINAR', NOW(), 'TUTORIAS')
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `upd_bitacoras_tut` AFTER UPDATE ON `tutorias`
 FOR EACH ROW INSERT INTO bitacoras(host, usuario, operacion, modificado, tabla) VALUES (SUBSTRING(USER(), (INSTR(USER(),'@')+1)), SUBSTRING(USER(),1,(instr(user(),'@')-1)), 'ACTUALIZAR', NOW(), 'TUTORIAS')
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `nombre` varchar(128) DEFAULT NULL,
  `username` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `role` varchar(64) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `nombre`, `username`, `password`, `email`, `role`, `created`, `modified`, `status`) VALUES
(1, 'Aurelio Hernandez Briones', '11040039', '4d0a23dfac8ddee374f0df4e371b94c0ca853074', 'yeyo1993@itszo.com', 'Alumno', '2015-03-27 06:27:03', '2015-05-06 22:31:29', 1),
(4, 'panchito', 'academico', '4d0a23dfac8ddee374f0df4e371b94c0ca853074', 'academico@itszo.com', 'Academico', '2015-04-25 00:56:16', '2015-04-25 00:56:16', 1),
(5, 'lolita', 'tutoria', '4d0a23dfac8ddee374f0df4e371b94c0ca853074', 'lolita@itszo.com', 'Tutoria', '2015-04-25 00:56:49', '2015-04-25 00:56:49', 1),
(6, 'paco', 'extracurricular', '4d0a23dfac8ddee374f0df4e371b94c0ca853074', 'paco@itszo.com', 'Extracurricular', '2015-04-25 00:58:14', '2015-04-25 02:50:24', 1),
(7, 'piratoÃ±o', 'formacion', '4d0a23dfac8ddee374f0df4e371b94c0ca853074', 'piratono@itszo.com', 'Formacion', '2015-04-25 00:58:56', '2015-04-25 00:58:56', 1),
(8, 'la madrina', 'investigacion', '4d0a23dfac8ddee374f0df4e371b94c0ca853074', 'madrina@itszo.com', 'Investigacion', '2015-04-25 00:59:39', '2015-04-25 00:59:39', 1),
(10, 'Saul Roman Barraza', 'administrador', '4d0a23dfac8ddee374f0df4e371b94c0ca853074', 'saul@itszo.com', 'Admin', '2015-05-06 22:29:57', '2015-05-06 22:29:57', 1);

-- --------------------------------------------------------

--
-- Estructura para la vista `facademicas`
--
DROP TABLE IF EXISTS `facademicas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `facademicas` AS select `alumnos`.`id` AS `id`,`alumnos`.`matricula` AS `matricula`,`alumnos`.`nombre` AS `nombre`,`alumnos`.`apellidopaterno` AS `apellidopaterno`,`alumnos`.`apellidomaterno` AS `apellidomaterno`,`alumnos`.`semestre` AS `semestre`,`alumnos`.`created` AS `created`,`alumnos`.`modified` AS `modified` from `alumnos` where (`alumnos`.`matricula` in (select `academicas`.`matricula` from `academicas` where (`academicas`.`porcentaje` < 100)) and (`alumnos`.`semestre` > 8));

-- --------------------------------------------------------

--
-- Estructura para la vista `fextracurriculars`
--
DROP TABLE IF EXISTS `fextracurriculars`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fextracurriculars` AS select `alumnos`.`id` AS `id`,`alumnos`.`matricula` AS `matricula`,`alumnos`.`nombre` AS `nombre`,`alumnos`.`apellidopaterno` AS `apellidopaterno`,`alumnos`.`apellidomaterno` AS `apellidomaterno`,`alumnos`.`semestre` AS `semestre`,`alumnos`.`created` AS `created`,`alumnos`.`modified` AS `modified` from `alumnos` where (`alumnos`.`matricula` in (select `extracurriculars`.`matricula` from `extracurriculars` where (`extracurriculars`.`porcentaje` < 100)) and (`alumnos`.`semestre` > 6));

-- --------------------------------------------------------

--
-- Estructura para la vista `fformacions`
--
DROP TABLE IF EXISTS `fformacions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fformacions` AS select `alumnos`.`id` AS `id`,`alumnos`.`matricula` AS `matricula`,`alumnos`.`nombre` AS `nombre`,`alumnos`.`apellidopaterno` AS `apellidopaterno`,`alumnos`.`apellidomaterno` AS `apellidomaterno`,`alumnos`.`semestre` AS `semestre`,`alumnos`.`created` AS `created`,`alumnos`.`modified` AS `modified` from `alumnos` where (`alumnos`.`matricula` in (select `formacions`.`matricula` from `formacions` where (`formacions`.`porcentaje` < 100)) and (`alumnos`.`semestre` > 8));

-- --------------------------------------------------------

--
-- Estructura para la vista `finvestigacions`
--
DROP TABLE IF EXISTS `finvestigacions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `finvestigacions` AS select `alumnos`.`id` AS `id`,`alumnos`.`matricula` AS `matricula`,`alumnos`.`nombre` AS `nombre`,`alumnos`.`apellidopaterno` AS `apellidopaterno`,`alumnos`.`apellidomaterno` AS `apellidomaterno`,`alumnos`.`semestre` AS `semestre`,`alumnos`.`created` AS `created`,`alumnos`.`modified` AS `modified` from `alumnos` where (`alumnos`.`matricula` in (select `investigacions`.`matricula` from `investigacions` where (`investigacions`.`porcentaje` < 100)) and (`alumnos`.`semestre` > 8));

-- --------------------------------------------------------

--
-- Estructura para la vista `ftutorias`
--
DROP TABLE IF EXISTS `ftutorias`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ftutorias` AS select `alumnos`.`id` AS `id`,`alumnos`.`matricula` AS `matricula`,`alumnos`.`nombre` AS `nombre`,`alumnos`.`apellidopaterno` AS `apellidopaterno`,`alumnos`.`apellidomaterno` AS `apellidomaterno`,`alumnos`.`semestre` AS `semestre`,`alumnos`.`created` AS `created`,`alumnos`.`modified` AS `modified` from `alumnos` where (`alumnos`.`matricula` in (select `tutorias`.`matricula` from `tutorias` where (`tutorias`.`porcentaje` < 100)) and (`alumnos`.`semestre` > 4));

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `academicas`
--
ALTER TABLE `academicas`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `bitacoras`
--
ALTER TABLE `bitacoras`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `extracurriculars`
--
ALTER TABLE `extracurriculars`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `formacions`
--
ALTER TABLE `formacions`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `investigacions`
--
ALTER TABLE `investigacions`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tutorias`
--
ALTER TABLE `tutorias`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `academicas`
--
ALTER TABLE `academicas`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `alumnos`
--
ALTER TABLE `alumnos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `bitacoras`
--
ALTER TABLE `bitacoras`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT de la tabla `extracurriculars`
--
ALTER TABLE `extracurriculars`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `formacions`
--
ALTER TABLE `formacions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `investigacions`
--
ALTER TABLE `investigacions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `tutorias`
--
ALTER TABLE `tutorias`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
